export const firebaseConfig = {
  apiKey: "AIzaSyB2gdbYSgiRI5n0ckjEIu_rtS4RzM3ezho",
  authDomain: "applycodes-2683f.firebaseapp.com",
  projectId: "applycodes-2683f",
  storageBucket: "applycodes-2683f.firebasestorage.app",
  messagingSenderId: "697220767333",
  appId: "1:697220767333:web:5f1019152e66f489dbf08c",
  measurementId: "G-Z78WVK7LDG"
};
